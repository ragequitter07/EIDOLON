// Neural Network Background Animation
class NeuralNetwork {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.particles = [];
        this.particleCount = 50;
        this.connectionDistance = 150;
        
        this.resize();
        this.init();
        
        window.addEventListener('resize', () => this.resize());
    }
    
    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    init() {
        this.particles = [];
        for (let i = 0; i < this.particleCount; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 1
            });
        }
    }
    
    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Update and draw particles
        this.particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            // Wrap around edges
            if (particle.x < 0) particle.x = this.canvas.width;
            if (particle.x > this.canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = this.canvas.height;
            if (particle.y > this.canvas.height) particle.y = 0;
            
            // Draw particle
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = 'rgba(57, 255, 20, 0.5)';
            this.ctx.fill();
        });
        
        // Draw connections
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const dx = this.particles[i].x - this.particles[j].x;
                const dy = this.particles[i].y - this.particles[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < this.connectionDistance) {
                    const opacity = (1 - distance / this.connectionDistance) * 0.3;
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.particles[i].x, this.particles[i].y);
                    this.ctx.lineTo(this.particles[j].x, this.particles[j].y);
                    this.ctx.strokeStyle = `rgba(57, 255, 20, ${opacity})`;
                    this.ctx.lineWidth = 1;
                    this.ctx.stroke();
                }
            }
        }
        
        requestAnimationFrame(() => this.animate());
    }
}

// Initialize Neural Network
const neuralCanvas = document.getElementById('neuralCanvas');
if (neuralCanvas) {
    const network = new NeuralNetwork(neuralCanvas);
    network.animate();
}

// Smooth Scrolling
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Navigation Scroll Effect
const nav = document.querySelector('.nav');
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});

// Learn More Button
const learnMoreBtn = document.getElementById('learnMoreBtn');
if (learnMoreBtn) {
    learnMoreBtn.addEventListener('click', () => {
        const featuresSection = document.getElementById('how-it-works');
        if (featuresSection) {
            const offsetTop = featuresSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
}

// Demo Modal Functionality
const demoModal = document.getElementById('demoModal');
const startDemoBtn = document.getElementById('startDemoBtn');
const closeDemoBtn = document.getElementById('closeDemoBtn');
const returnToSiteBtn = document.getElementById('returnToSiteBtn');
const playPauseBtn = document.getElementById('playPauseBtn');
const resetBtn = document.getElementById('resetBtn');
const speedSlider = document.getElementById('speedSlider');
const speedValue = document.getElementById('speedValue');

// Demo State
let demoState = {
    isPlaying: false,
    currentTime: 0,
    speed: 1,
    totalDuration: 180,
    animationFrame: null,
    lastTimestamp: 0,
    events: [],
    nodes: [],
    predictions: [],
    eixScore: 45,
    showSolutions: true
};

// Demo Data with Solutions
// Demo Timeline based on provided data
const demoTimeline = [
    { 
        id: 1, timestamp: 0, 
        title: "Reconnaissance Detected", 
        event: "Unusual DNS queries from external IP detected", 
        type: "alert", severity: "medium", 
        action: "EIDOLON Response: Suspect IP added to watchlist - behavioral profiling initiated",
        solution: "Suspect IP added to watchlist - behavioral profiling initiated",
        solutionType: "monitoring", 
        affectedNodes: ["entry_point"],
        icon: "🔍"
    },
    { 
        id: 2, timestamp: 15, 
        title: "Digital Twin Created", 
        event: "EIDOLON threat actor profile initialized", 
        type: "system", severity: "info", 
        action: "Digital twin established - real-time behavioral tracking active",
        solution: "Digital twin established - real-time behavioral tracking active",
        solutionType: "profiling",
        affectedNodes: [],
        icon: "🤖"
    },
    { 
        id: 3, timestamp: 30, 
        title: "Phishing Email Detected", 
        event: "Malicious email with obfuscated payload detected", 
        type: "alert", severity: "high", 
        action: "Email quarantined - malicious link blocked - user awareness alert sent",
        solution: "Email quarantined - malicious link blocked - user awareness alert sent",
        solutionType: "containment",
        affectedNodes: ["email_server"],
        icon: "📧"
    },
    { 
        id: 4, timestamp: 45, 
        title: "Initial Access - User Compromised", 
        event: "User executed malicious attachment - workstation compromised", 
        type: "alert", severity: "critical", 
        action: "Workstation auto-isolated from network - compromised credentials flagged globally",
        solution: "Workstation auto-isolated from network - compromised credentials flagged globally",
        solutionType: "isolation",
        affectedNodes: ["workstation_1"],
        icon: "🚨"
    },
    { 
        id: 5, timestamp: 60, 
        title: "Lateral Movement Attempt", 
        event: "Threat attempting to move from workstation to file server", 
        type: "alert", severity: "critical", 
        action: "Firewall rules dynamically updated - lateral movement path blocked",
        solution: "Firewall rules dynamically updated - lateral movement path blocked",
        solutionType: "prevention",
        affectedNodes: ["workstation_1", "file_server"],
        icon: "🛡️"
    },
    { 
        id: 6, timestamp: 75, 
        title: "Privilege Escalation Predicted", 
        event: "EIDOLON predicts escalation to domain controller (94% confidence)", 
        type: "prediction", severity: "critical", 
        confidence: 94,
        action: "Admin account protections enhanced - multi-factor authentication enforced globally",
        solution: "Admin account protections enhanced - multi-factor authentication enforced globally",
        solutionType: "hardening",
        affectedNodes: ["domain_controller"],
        icon: "🔮"
    },
    { 
        id: 7, timestamp: 90, 
        title: "Privilege Escalation Blocked", 
        event: "Escalation attempt detected and automatically blocked", 
        type: "alert", severity: "critical", 
        action: "Escalation attempt denied - threat actor credentials revoked - backup admin locked",
        solution: "Escalation attempt denied - threat actor credentials revoked - backup admin locked",
        solutionType: "prevention",
        affectedNodes: ["domain_controller"],
        icon: "🔐"
    },
    { 
        id: 8, timestamp: 105, 
        title: "False Positive Pruned", 
        event: "Benign process flagged - validation confirms non-threatening", 
        type: "validation", severity: "low", 
        action: "False positive removed - system cleared - alert suppression rules updated",
        solution: "False positive removed - system cleared - alert suppression rules updated",
        solutionType: "remediation",
        affectedNodes: ["file_server"],
        icon: "✓"
    },
    { 
        id: 9, timestamp: 120, 
        title: "Data Exfiltration Risk", 
        event: "EIDOLON predicts database access attempt (92% confidence)", 
        type: "prediction", severity: "critical", 
        confidence: 92,
        action: "Database access controls tightened - suspicious query patterns blocked - alert queued",
        solution: "Database access controls tightened - suspicious query patterns blocked - alert queued",
        solutionType: "prevention",
        affectedNodes: ["database_server"],
        icon: "💾"
    },
    { 
        id: 10, timestamp: 135, 
        title: "Sandbox Simulation Complete", 
        event: "Behavior replicated in secure sandbox - 3 attack vectors confirmed", 
        type: "system", severity: "critical", 
        action: "Validation confirms threat authenticity - countermeasures deployed across network",
        solution: "Validation confirms threat authenticity - countermeasures deployed across network",
        solutionType: "validation",
        affectedNodes: ["database_server"],
        icon: "🧪"
    },
    { 
        id: 11, timestamp: 150, 
        title: "Adversary Adaptation", 
        event: "Threat actor changes tactics - new behavioral pattern detected", 
        type: "system", severity: "critical", 
        action: "Behavioral model updated in real-time - new threat signatures deployed to all systems",
        solution: "Behavioral model updated in real-time - new threat signatures deployed to all systems",
        solutionType: "adaptation",
        affectedNodes: [],
        icon: "⚙️"
    },
    { 
        id: 12, timestamp: 180, 
        title: "Threat Neutralized", 
        event: "All attack vectors contained - incident response complete", 
        type: "summary", severity: "resolved", 
        action: "All systems restored - forensic analysis complete - incident report generated - threat eliminated",
        solution: "All systems restored - forensic analysis complete - incident report generated - threat eliminated",
        solutionType: "resolution",
        affectedNodes: ["workstation_1", "file_server", "domain_controller", "database_server"],
        icon: "✅"
    }
];

// Network nodes in circular topology
const networkNodes = [
    { id: "entry_point", name: "Entry Point", x: 0.5, y: 0.15, status: "safe", threatTime: 0, solutionTime: 15 },
    { id: "email_server", name: "Email Server", x: 0.85, y: 0.3, status: "safe", threatTime: 30, solutionTime: 35 },
    { id: "workstation_1", name: "Workstation", x: 0.85, y: 0.7, status: "safe", threatTime: 45, solutionTime: 50 },
    { id: "file_server", name: "File Server", x: 0.5, y: 0.85, status: "safe", threatTime: 60, solutionTime: 65 },
    { id: "domain_controller", name: "Domain Controller", x: 0.15, y: 0.7, status: "safe", threatTime: 75, solutionTime: 90 },
    { id: "database_server", name: "Database Server", x: 0.15, y: 0.3, status: "safe", threatTime: 120, solutionTime: 125 }
];

const predictions = [
    { id: 1, phase: "Lateral Movement", target: "File Server", confidence: 94, showTime: 45 },
    { id: 2, phase: "Privilege Escalation", target: "Domain Controller", confidence: 89, showTime: 75 },
    { id: 3, phase: "Data Exfiltration", target: "Database Server", confidence: 92, showTime: 105 },
    { id: 4, phase: "Threat Neutralization", target: "All Systems Secured", confidence: 97, showTime: 150 }
];

// Network Canvas
const networkCanvas = document.getElementById('networkCanvas');
const networkCtx = networkCanvas ? networkCanvas.getContext('2d') : null;

function initNetworkCanvas() {
    if (!networkCanvas) return;
    networkCanvas.width = networkCanvas.offsetWidth;
    networkCanvas.height = networkCanvas.offsetHeight;
}

function drawNetwork() {
    if (!networkCtx) return;
    
    networkCtx.clearRect(0, 0, networkCanvas.width, networkCanvas.height);
    
    const width = networkCanvas.width;
    const height = networkCanvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    
    // Draw connections between all nodes
    networkCtx.lineWidth = 2;
    
    for (let i = 0; i < networkNodes.length; i++) {
        for (let j = i + 1; j < networkNodes.length; j++) {
            const node1 = networkNodes[i];
            const node2 = networkNodes[j];
            
            let strokeColor = 'rgba(57, 255, 20, 0.15)';
            let dashPattern = [];
            
            // Color connections based on threat status
            if (node1.status === 'compromised' || node2.status === 'compromised') {
                strokeColor = 'rgba(255, 68, 68, 0.4)';
            } else if (node1.status === 'warning' || node2.status === 'warning') {
                strokeColor = 'rgba(255, 165, 0, 0.3)';
            } else if (node1.status === 'protected' || node2.status === 'protected') {
                strokeColor = 'rgba(0, 191, 255, 0.3)';
                dashPattern = [5, 5];
            }
            
            networkCtx.strokeStyle = strokeColor;
            networkCtx.setLineDash(dashPattern);
            networkCtx.beginPath();
            networkCtx.moveTo(node1.x * width, node1.y * height);
            networkCtx.lineTo(node2.x * width, node2.y * height);
            networkCtx.stroke();
            networkCtx.setLineDash([]);
        }
    }
    
    // Draw nodes
    networkNodes.forEach(node => {
        const x = node.x * width;
        const y = node.y * height;
        
        // Determine colors based on status
        let glowColor, nodeColor, glowRadius;
        
        switch(node.status) {
            case 'compromised':
                glowColor = 'rgba(255, 68, 68, 0.6)';
                nodeColor = '#ff4444';
                glowRadius = 30;
                break;
            case 'warning':
                glowColor = 'rgba(255, 165, 0, 0.5)';
                nodeColor = '#ffa500';
                glowRadius = 28;
                break;
            case 'protected':
                glowColor = 'rgba(0, 191, 255, 0.6)';
                nodeColor = '#00bfff';
                glowRadius = 28;
                break;
            case 'resolved':
                glowColor = 'rgba(0, 255, 136, 0.6)';
                nodeColor = '#00ff88';
                glowRadius = 28;
                break;
            default:
                glowColor = 'rgba(57, 255, 20, 0.3)';
                nodeColor = '#39ff14';
                glowRadius = 25;
        }
        
        // Outer glow
        networkCtx.beginPath();
        networkCtx.arc(x, y, glowRadius, 0, Math.PI * 2);
        networkCtx.fillStyle = glowColor;
        networkCtx.fill();
        
        // Inner circle
        networkCtx.beginPath();
        networkCtx.arc(x, y, 18, 0, Math.PI * 2);
        networkCtx.fillStyle = nodeColor;
        networkCtx.fill();
        
        // Add border
        networkCtx.beginPath();
        networkCtx.arc(x, y, 18, 0, Math.PI * 2);
        networkCtx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        networkCtx.lineWidth = 2;
        networkCtx.stroke();
        
        // Draw protection shield for protected nodes
        if (node.status === 'protected') {
            networkCtx.beginPath();
            networkCtx.arc(x, y, 25, 0, Math.PI * 2);
            networkCtx.strokeStyle = '#00bfff';
            networkCtx.lineWidth = 3;
            networkCtx.setLineDash([3, 3]);
            networkCtx.stroke();
            networkCtx.setLineDash([]);
            networkCtx.lineWidth = 2;
        }
        
        // Draw checkmark for resolved nodes
        if (node.status === 'resolved') {
            networkCtx.fillStyle = '#ffffff';
            networkCtx.font = 'bold 16px Arial';
            networkCtx.textAlign = 'center';
            networkCtx.textBaseline = 'middle';
            networkCtx.fillText('✓', x, y);
        }
        
        // Node label
        networkCtx.fillStyle = '#c9d1d9';
        networkCtx.font = 'bold 13px Arial';
        networkCtx.textAlign = 'center';
        networkCtx.textBaseline = 'alphabetic';
        networkCtx.fillText(node.name, x, y + 45);
    });
}

function updateNetwork(currentTime) {
    // Check if threat neutralized (final event)
    if (currentTime >= 180) {
        networkNodes.forEach(node => {
            node.status = 'resolved';
        });
    } else {
        networkNodes.forEach(node => {
            // Determine node status based on timeline events
            if (node.threatTime >= 0 && currentTime >= node.threatTime) {
                if (node.solutionTime >= 0 && currentTime >= node.solutionTime + 5) {
                    node.status = 'resolved';
                } else if (node.solutionTime >= 0 && currentTime >= node.solutionTime) {
                    node.status = 'protected';
                } else if (currentTime >= node.threatTime + 5) {
                    node.status = 'compromised';
                } else {
                    node.status = 'warning';
                }
            } else {
                node.status = 'safe';
            }
        });
    }
    
    drawNetwork();
}







function updateTimeDisplay() {
    const currentTimeEl = document.getElementById('currentTime');
    if (!currentTimeEl) return;
    
    const minutes = Math.floor(demoState.currentTime / 60);
    const seconds = Math.floor(demoState.currentTime % 60);
    currentTimeEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function processDemoTimeline(currentTime) {
    demoTimeline.forEach(event => {
        if (event.timestamp <= currentTime && !demoState.events.includes(event.timestamp)) {
            demoState.events.push(event.timestamp);
            addSolutionToFeed(event);
            updateCurrentEventInfo(event);
        }
    });
}

function animateDemo(timestamp) {
    if (!demoState.isPlaying) return;
    
    if (!demoState.lastTimestamp) demoState.lastTimestamp = timestamp;
    const deltaTime = (timestamp - demoState.lastTimestamp) / 1000;
    demoState.lastTimestamp = timestamp;
    
    demoState.currentTime += deltaTime * demoState.speed;
    
    if (demoState.currentTime >= demoState.totalDuration) {
        demoState.currentTime = demoState.totalDuration;
        pauseDemo();
    }
    
    processDemoTimeline(demoState.currentTime);
    updateNetwork(demoState.currentTime);
    updateTimeDisplay();
    updateProgressBar();
    updateTimelineHighlight();
    
    if (demoState.isPlaying) {
        demoState.animationFrame = requestAnimationFrame(animateDemo);
    }
}

function playDemo() {
    demoState.isPlaying = true;
    demoState.lastTimestamp = 0;
    const icon = document.getElementById('playPauseIcon');
    if (icon) icon.textContent = '⏸';
    demoState.animationFrame = requestAnimationFrame(animateDemo);
}

function pauseDemo() {
    demoState.isPlaying = false;
    const icon = document.getElementById('playPauseIcon');
    if (icon) icon.textContent = '▶';
    if (demoState.animationFrame) {
        cancelAnimationFrame(demoState.animationFrame);
    }
}

function resetDemo() {
    pauseDemo();
    demoState.currentTime = 0;
    demoState.events = [];
    demoState.lastTimestamp = 0;
    
    // Reset network nodes
    networkNodes.forEach(node => {
        node.status = 'safe';
    });
    
    // Clear solutions feed
    const solutionsFeed = document.getElementById('solutionsFeed');
    if (solutionsFeed) solutionsFeed.innerHTML = '';
    
    // Reset current event info
    const currentEventInfo = document.getElementById('currentEventInfo');
    if (currentEventInfo) {
        currentEventInfo.innerHTML = '<p class="info-placeholder">Press Play to start the demo</p>';
    }
    
    updateTimeDisplay();
    updateProgressBar();
    updateTimelineHighlight();
    drawNetwork();
}

function initTimelineEvents() {
    const timelineEvents = document.getElementById('timelineEvents');
    if (!timelineEvents) return;
    
    timelineEvents.innerHTML = '';
    
    demoTimeline.forEach((event, index) => {
        const eventItem = document.createElement('div');
        eventItem.className = 'timeline-event-item';
        eventItem.dataset.eventId = event.id;
        
        const minutes = Math.floor(event.timestamp / 60);
        const seconds = event.timestamp % 60;
        const timeStr = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        eventItem.innerHTML = `
            <div class="timeline-event-time">${timeStr}</div>
            <div class="timeline-event-title">${event.title}</div>
            <div class="timeline-event-severity ${event.severity}">${event.severity.toUpperCase()}</div>
        `;
        
        eventItem.addEventListener('click', () => {
            jumpToEvent(event.timestamp);
        });
        
        timelineEvents.appendChild(eventItem);
    });
}

function jumpToEvent(timestamp) {
    demoState.currentTime = timestamp;
    demoState.events = [];
    demoState.lastTimestamp = 0;
    processDemoTimeline(timestamp);
    updateNetwork(timestamp);
    updateTimeDisplay();
    updateProgressBar();
    updateTimelineHighlight();
}

function updateTimelineHighlight() {
    const timelineItems = document.querySelectorAll('.timeline-event-item');
    let currentEventId = null;
    
    for (let i = demoTimeline.length - 1; i >= 0; i--) {
        if (demoState.currentTime >= demoTimeline[i].timestamp) {
            currentEventId = demoTimeline[i].id;
            break;
        }
    }
    
    timelineItems.forEach(item => {
        const eventId = parseInt(item.dataset.eventId);
        
        if (eventId === currentEventId) {
            item.classList.add('active');
            item.classList.remove('completed');
        } else if (demoState.currentTime > demoTimeline.find(e => e.id === eventId).timestamp) {
            item.classList.add('completed');
            item.classList.remove('active');
        } else {
            item.classList.remove('active', 'completed');
        }
    });
}

function updateProgressBar() {
    const progressFill = document.getElementById('progressFill');
    if (!progressFill) return;
    
    const progress = (demoState.currentTime / demoState.totalDuration) * 100;
    progressFill.style.width = progress + '%';
}

function updateCurrentEventInfo(event) {
    const currentEventInfo = document.getElementById('currentEventInfo');
    if (!currentEventInfo || !event) return;
    
    const confidenceHtml = event.confidence ? `<p><strong>Confidence:</strong> ${event.confidence}%</p>` : '';
    
    currentEventInfo.innerHTML = `
        <div class="event-info-title">${event.icon} ${event.title}</div>
        <div class="event-info-desc"><strong>Event:</strong> ${event.event}</div>
        ${confidenceHtml}
        <div class="event-info-action"><strong>Action:</strong> ${event.action}</div>
    `;
}

function addSolutionToFeed(event) {
    if (!event.solution) return;
    
    const solutionsFeed = document.getElementById('solutionsFeed');
    if (!solutionsFeed) return;
    
    const solutionItem = document.createElement('div');
    solutionItem.className = 'solution-item';
    
    const minutes = Math.floor(event.timestamp / 60);
    const seconds = event.timestamp % 60;
    const timeStr = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    solutionItem.innerHTML = `
        <div class="solution-header">
            <span class="solution-icon">${event.icon || '✓'}</span>
            <span class="solution-type">${event.solutionType.toUpperCase()}</span>
        </div>
        <div class="solution-description">${event.solution}</div>
        <div class="solution-time">${timeStr}<span class="solution-status completed">COMPLETED</span></div>
    `;
    
    solutionsFeed.insertBefore(solutionItem, solutionsFeed.firstChild);
    
    // Keep only last 10 solutions
    while (solutionsFeed.children.length > 10) {
        solutionsFeed.removeChild(solutionsFeed.lastChild);
    }
}

function openDemoModal() {
    if (demoModal) {
        demoModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        initNetworkCanvas();
        initTimelineEvents();
        resetDemo();
        drawNetwork();
        setTimeout(() => playDemo(), 800);
    }
}

function closeDemoModal() {
    if (demoModal) {
        demoModal.classList.remove('active');
        document.body.style.overflow = '';
        resetDemo();
    }
}

// Event Listeners
if (startDemoBtn) {
    startDemoBtn.addEventListener('click', openDemoModal);
}

if (closeDemoBtn) {
    closeDemoBtn.addEventListener('click', closeDemoModal);
}

if (returnToSiteBtn) {
    returnToSiteBtn.addEventListener('click', () => {
        closeDemoModal();
        const contactSection = document.getElementById('contact');
        if (contactSection) {
            setTimeout(() => {
                const offsetTop = contactSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }, 300);
        }
    });
}

if (playPauseBtn) {
    playPauseBtn.addEventListener('click', () => {
        if (demoState.isPlaying) {
            pauseDemo();
        } else {
            playDemo();
        }
    });
}

if (resetBtn) {
    resetBtn.addEventListener('click', resetDemo);
}

if (speedSlider) {
    speedSlider.addEventListener('input', (e) => {
        demoState.speed = parseFloat(e.target.value);
        if (speedValue) {
            speedValue.textContent = demoState.speed + 'x';
        }
    });
}

// Visualization layer toggles
const toggleThreats = document.getElementById('toggleThreats');
const togglePredictions = document.getElementById('togglePredictions');
const toggleSolutions = document.getElementById('toggleSolutions');
const togglePaths = document.getElementById('togglePaths');

if (toggleSolutions) {
    toggleSolutions.addEventListener('change', (e) => {
        const solutionsFeed = document.getElementById('solutionsFeed');
        if (solutionsFeed) {
            solutionsFeed.parentElement.style.display = e.target.checked ? 'flex' : 'none';
        }
    });
}

if (togglePaths) {
    togglePaths.addEventListener('change', (e) => {
        if (networkCanvas) {
            networkCanvas.style.opacity = e.target.checked ? '1' : '0.5';
        }
    });
}



// Close modal on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && demoModal && demoModal.classList.contains('active')) {
        closeDemoModal();
    }
});

// Resize network canvas on window resize
window.addEventListener('resize', () => {
    if (demoModal && demoModal.classList.contains('active')) {
        initNetworkCanvas();
        drawNetwork();
    }
});

// Animated Counters for Metrics (Preserved from original)
function animateCounter(element, target, duration = 2000, suffix = '%') {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        if (suffix === 's') {
            element.textContent = current.toFixed(1) + suffix;
        } else if (suffix === '%') {
            element.textContent = Math.floor(current) + suffix;
        } else {
            element.textContent = Math.floor(current) + suffix;
        }
    }, 16);
}

// Intersection Observer for Animations
const observerOptions = {
    threshold: 0.3,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            // Animate metric counters
            const metricValue = entry.target.querySelector('.metric-value[data-value]');
            if (metricValue && !metricValue.classList.contains('animated')) {
                metricValue.classList.add('animated');
                const targetValue = parseFloat(metricValue.getAttribute('data-value'));
                
                if (metricValue.textContent.includes('s')) {
                    animateCounter(metricValue, targetValue, 2000, 's');
                } else {
                    animateCounter(metricValue, targetValue, 2000, '%');
                }
            }
            
            // Animate KPI values
            const kpiValue = entry.target.querySelector('.kpi-value[data-kpi]');
            if (kpiValue && !kpiValue.classList.contains('animated')) {
                kpiValue.classList.add('animated');
                const targetValue = parseFloat(kpiValue.getAttribute('data-kpi'));
                
                if (kpiValue.textContent.includes('s')) {
                    animateCounter(kpiValue, targetValue, 2000, 's');
                } else if (kpiValue.textContent.includes('%')) {
                    animateCounter(kpiValue, targetValue, 2000, '%');
                } else {
                    animateCounter(kpiValue, targetValue, 2000, '');
                }
            }
            
            // Animate progress bars
            const progressBar = entry.target.querySelector('.progress-bar[data-progress]');
            if (progressBar && !progressBar.classList.contains('animated')) {
                progressBar.classList.add('animated');
                const targetProgress = parseFloat(progressBar.getAttribute('data-progress'));
                progressBar.style.width = targetProgress + '%';
            }
            
            // Animate EiX gauges
            const gaugeFill = entry.target.querySelector('.gauge-fill[data-score]');
            if (gaugeFill && !gaugeFill.classList.contains('animated')) {
                gaugeFill.classList.add('animated');
                const score = parseFloat(gaugeFill.getAttribute('data-score'));
                const maxDashArray = 251.2;
                const offset = maxDashArray * (1 - score / 100);
                gaugeFill.style.strokeDashoffset = offset;
            }
        }
    });
}, observerOptions);

// Observe all metric cards
const metricCards = document.querySelectorAll('.metric-card');
metricCards.forEach(card => observer.observe(card));

// Observe all KPI items
const kpiItems = document.querySelectorAll('.kpi-item');
kpiItems.forEach(item => observer.observe(item));

// Observe all simulation items with progress bars
const simulationItems = document.querySelectorAll('.simulation-item');
simulationItems.forEach(item => observer.observe(item));

// Observe EiX cards
const eixCards = document.querySelectorAll('.eix-card');
eixCards.forEach(card => observer.observe(card));

// Feature Card Expansion
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach(card => {
    card.addEventListener('click', () => {
        const expanded = card.querySelector('.feature-expanded');
        const isExpanded = expanded.style.maxHeight && expanded.style.maxHeight !== '0px';
        
        // Close all other expanded cards
        featureCards.forEach(otherCard => {
            if (otherCard !== card) {
                const otherExpanded = otherCard.querySelector('.feature-expanded');
                otherExpanded.style.maxHeight = '0';
            }
        });
        
        // Toggle current card
        if (isExpanded) {
            expanded.style.maxHeight = '0';
        } else {
            expanded.style.maxHeight = expanded.scrollHeight + 'px';
        }
    });
});

// Alert Item Hover Effects
const alertItems = document.querySelectorAll('.alert-item');
alertItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        item.style.transform = 'translateX(10px)';
    });
    
    item.addEventListener('mouseleave', () => {
        item.style.transform = 'translateX(0)';
    });
});

// Dashboard Card Expansion
let expandedCard = null;

const dashboardCards = document.querySelectorAll('.dashboard-card');
dashboardCards.forEach(card => {
    card.addEventListener('click', () => {
        if (expandedCard && expandedCard !== card) {
            expandedCard.style.transform = 'scale(1)';
            expandedCard.style.zIndex = '1';
        }
        
        if (expandedCard === card) {
            card.style.transform = 'scale(1)';
            card.style.zIndex = '1';
            expandedCard = null;
        } else {
            card.style.transform = 'scale(1.02)';
            card.style.zIndex = '10';
            expandedCard = card;
        }
    });
});

// Path Node Animation on Scroll
const pathNodes = document.querySelectorAll('.path-node');
const pathObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'scale(1)';
        }
    });
}, { threshold: 0.5 });

pathNodes.forEach(node => {
    node.style.opacity = '0';
    node.style.transform = 'scale(0.8)';
    node.style.transition = 'all 0.5s ease';
    pathObserver.observe(node);
});

// Simulate Real-Time Data Updates
function simulateRealTimeUpdates() {
    // Update active simulations count with pulse
    const activeSimValue = document.querySelector('.sim-value.pulse');
    if (activeSimValue) {
        setInterval(() => {
            const currentValue = parseInt(activeSimValue.textContent);
            const newValue = currentValue + (Math.random() > 0.5 ? 1 : -1);
            if (newValue >= 5 && newValue <= 10) {
                activeSimValue.textContent = newValue;
            }
        }, 5000);
    }
    
    // Add subtle glow animation to critical alerts
    const criticalAlerts = document.querySelectorAll('.alert-item.priority-critical');
    criticalAlerts.forEach(alert => {
        setInterval(() => {
            alert.style.boxShadow = '0 0 20px rgba(255, 68, 68, 0.3)';
            setTimeout(() => {
                alert.style.boxShadow = 'none';
            }, 1000);
        }, 3000);
    });
}

// Initialize real-time updates
simulateRealTimeUpdates();

// Tooltip functionality for EiX cards
const eixElements = document.querySelectorAll('.eix-card');
eixElements.forEach(card => {
    card.addEventListener('mouseenter', () => {
        const riskBadge = card.querySelector('.risk-badge');
        if (riskBadge) {
            riskBadge.style.transform = 'scale(1.1)';
        }
    });
    
    card.addEventListener('mouseleave', () => {
        const riskBadge = card.querySelector('.risk-badge');
        if (riskBadge) {
            riskBadge.style.transform = 'scale(1)';
        }
    });
});

// Timeline Animation
const timelineItems = document.querySelectorAll('.timeline-item');
const timelineObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translate(-50%, -50%) scale(1)';
            }, index * 200);
        }
    });
}, { threshold: 0.5 });

timelineItems.forEach(item => {
    item.style.opacity = '0';
    item.style.transform = 'translate(-50%, -50%) scale(0.5)';
    item.style.transition = 'all 0.5s ease';
    timelineObserver.observe(item);
});

// Keyboard Navigation Support
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && expandedCard) {
        expandedCard.style.transform = 'scale(1)';
        expandedCard.style.zIndex = '1';
        expandedCard = null;
    }
});

// Initialize on page load
window.addEventListener('load', () => {
    // Add entrance animations
    document.body.style.opacity = '1';
    
    // Trigger initial animations for visible elements
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        heroContent.style.animation = 'fadeInUp 1s ease forwards';
    }
});

// Add CSS animation keyframes dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    body {
        opacity: 0;
        transition: opacity 0.3s ease;
    }
`;
document.head.appendChild(style);

console.log('EIDOLON - AI-Driven Threat Intelligence Platform Initialized');