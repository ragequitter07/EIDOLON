// Neural Network Background Animation
class NeuralNetwork {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.particles = [];
        this.particleCount = 50;
        this.connectionDistance = 150;
        
        this.resize();
        this.init();
        
        window.addEventListener('resize', () => this.resize());
    }
    
    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    init() {
        this.particles = [];
        for (let i = 0; i < this.particleCount; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 1
            });
        }
    }
    
    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Update and draw particles
        this.particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            // Wrap around edges
            if (particle.x < 0) particle.x = this.canvas.width;
            if (particle.x > this.canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = this.canvas.height;
            if (particle.y > this.canvas.height) particle.y = 0;
            
            // Draw particle
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = 'rgba(57, 255, 20, 0.5)';
            this.ctx.fill();
        });
        
        // Draw connections
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const dx = this.particles[i].x - this.particles[j].x;
                const dy = this.particles[i].y - this.particles[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < this.connectionDistance) {
                    const opacity = (1 - distance / this.connectionDistance) * 0.3;
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.particles[i].x, this.particles[i].y);
                    this.ctx.lineTo(this.particles[j].x, this.particles[j].y);
                    this.ctx.strokeStyle = `rgba(57, 255, 20, ${opacity})`;
                    this.ctx.lineWidth = 1;
                    this.ctx.stroke();
                }
            }
        }
        
        requestAnimationFrame(() => this.animate());
    }
}

// Initialize Neural Network
const neuralCanvas = document.getElementById('neuralCanvas');
if (neuralCanvas) {
    const network = new NeuralNetwork(neuralCanvas);
    network.animate();
}

// Smooth Scrolling
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Navigation Scroll Effect
const nav = document.querySelector('.nav');
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});

// Learn More Button
const learnMoreBtn = document.getElementById('learnMoreBtn');
if (learnMoreBtn) {
    learnMoreBtn.addEventListener('click', () => {
        const featuresSection = document.getElementById('how-it-works');
        if (featuresSection) {
            const offsetTop = featuresSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
}

// Demo Modal Functionality
const demoModal = document.getElementById('demoModal');
const requestDemoBtn = document.getElementById('requestDemoBtn');
const contactDemoBtn = document.getElementById('contactDemoBtn');
const closeDemoBtn = document.getElementById('closeDemoBtn');
const returnToSiteBtn = document.getElementById('returnToSiteBtn');
const playPauseBtn = document.getElementById('playPauseBtn');
const resetBtn = document.getElementById('resetBtn');
const speedSlider = document.getElementById('speedSlider');
const speedValue = document.getElementById('speedValue');

// Demo State
let demoState = {
    isPlaying: false,
    currentTime: 0,
    speed: 1,
    totalDuration: 180,
    animationFrame: null,
    lastTimestamp: 0,
    events: [],
    nodes: [],
    predictions: [],
    eixScore: 45,
    showSolutions: true
};

// Demo Data with Solutions
const demoTimeline = [
    { timestamp: 0, event: "Reconnaissance detected", type: "alert", severity: "medium", description: "Unusual DNS queries detected", action: "Creating digital twin of adversary", solution: "Suspect IP isolated from network", solutionType: "isolation", icon: "🛡️" },
    { timestamp: 15, event: "Digital Twin Created", type: "system", severity: "info", description: "Behavioral profile initialized", action: "Analyzing threat patterns" },
    { timestamp: 30, event: "Initial access via phishing", type: "alert", severity: "high", description: "Malicious email attachment executed", action: "Predicting next likely moves", solution: "Compromised account auto-quarantined; password reset enforced", solutionType: "quarantine", icon: "🔒" },
    { timestamp: 45, event: "Prediction Generated", type: "prediction", severity: "high", description: "Next likely target: Domain Controller", confidence: 94, action: "Prioritizing for analyst review" },
    { timestamp: 60, event: "Lateral movement attempt", type: "alert", severity: "critical", description: "Lateral movement across network", action: "Updating threat model", solution: "File server access blocked; network segmentation activated", solutionType: "segmentation", icon: "🚧" },
    { timestamp: 75, event: "Privilege Escalation Predicted", type: "prediction", severity: "critical", description: "Predicted target: Administrator account", confidence: 89, action: "Sandbox simulation started" },
    { timestamp: 90, event: "Privilege escalation detected", type: "alert", severity: "critical", description: "Admin privilege attempt detected", action: "Automatic pruning initiated", solution: "Admin privileges revoked; alert sent to SOC", solutionType: "privileged_revoked", icon: "🔐" },
    { timestamp: 105, event: "Data exfiltration risk at database server", type: "alert", severity: "critical", description: "Predicted data target: Financial Records", confidence: 92, action: "Recommended immediate response", solution: "Firewall rules tightened; suspicious connections killed", solutionType: "exfiltration_blocked", icon: "🔥" },
    { timestamp: 120, event: "Adversary adaptation", type: "system", severity: "critical", description: "Threat actor changed tactics", action: "EiX score updated to 87%", solution: "Behavioral model updated; new rules auto-deployed", solutionType: "remediation", icon: "⚙️" },
    { timestamp: 135, event: "Sandbox Simulation Complete", type: "validation", severity: "high", description: "Simulation confirmed 3 attack vectors", action: "High confidence assessment ready" },
    { timestamp: 150, event: "Automated Response Initiated", type: "action", severity: "critical", description: "Blocking predicted compromise points", action: "Threat contained", solution: "All affected systems isolated and secured", solutionType: "remediation", icon: "✓" },
    { timestamp: 180, event: "Threat neutralized", type: "summary", severity: "high", description: "Attack campaign neutralized", action: "Full incident report generated", solution: "All affected systems restored; full report generated", solutionType: "threat_neutralized", icon: "✅" }
];

const networkNodes = [
    { id: 1, name: "User Workstation", x: 0.2, y: 0.5, status: "safe", compromiseTime: 0, solutionTime: 30, solutionType: "quarantine" },
    { id: 2, name: "File Server", x: 0.4, y: 0.3, status: "safe", compromiseTime: 45, solutionTime: 60, solutionType: "segmentation" },
    { id: 3, name: "Domain Controller", x: 0.6, y: 0.5, status: "safe", compromiseTime: 75, solutionTime: 90, solutionType: "privileged_revoked" },
    { id: 4, name: "Database Server", x: 0.8, y: 0.4, status: "safe", compromiseTime: 90, solutionTime: 105, solutionType: "exfiltration_blocked" },
    { id: 5, name: "Web Server", x: 0.5, y: 0.7, status: "safe", compromiseTime: -1, solutionTime: -1, solutionType: null }
];

const predictions = [
    { id: 1, phase: "Lateral Movement", target: "File Server", confidence: 94, showTime: 45 },
    { id: 2, phase: "Privilege Escalation", target: "Domain Controller", confidence: 89, showTime: 75 },
    { id: 3, phase: "Data Exfiltration", target: "Database Server", confidence: 92, showTime: 105 },
    { id: 4, phase: "Threat Neutralization", target: "All Systems Secured", confidence: 97, showTime: 150 }
];

// Network Canvas
const networkCanvas = document.getElementById('networkCanvas');
const networkCtx = networkCanvas ? networkCanvas.getContext('2d') : null;

function initNetworkCanvas() {
    if (!networkCanvas) return;
    networkCanvas.width = networkCanvas.offsetWidth;
    networkCanvas.height = networkCanvas.offsetHeight;
}

function drawNetwork() {
    if (!networkCtx) return;
    
    networkCtx.clearRect(0, 0, networkCanvas.width, networkCanvas.height);
    
    const width = networkCanvas.width;
    const height = networkCanvas.height;
    
    // Draw connections
    networkCtx.strokeStyle = 'rgba(57, 255, 20, 0.2)';
    networkCtx.lineWidth = 2;
    
    for (let i = 0; i < networkNodes.length; i++) {
        for (let j = i + 1; j < networkNodes.length; j++) {
            const node1 = networkNodes[i];
            const node2 = networkNodes[j];
            
            if (node1.status === 'compromised' || node2.status === 'compromised') {
                networkCtx.strokeStyle = 'rgba(255, 68, 68, 0.5)';
            } else if (node1.status === 'isolated' || node2.status === 'isolated') {
                networkCtx.strokeStyle = 'rgba(0, 191, 255, 0.4)';
                networkCtx.setLineDash([5, 5]);
            } else {
                networkCtx.strokeStyle = 'rgba(57, 255, 20, 0.2)';
                networkCtx.setLineDash([]);
            }
            
            networkCtx.beginPath();
            networkCtx.moveTo(node1.x * width, node1.y * height);
            networkCtx.lineTo(node2.x * width, node2.y * height);
            networkCtx.stroke();
            networkCtx.setLineDash([]);
        }
    }
    
    // Draw nodes
    networkNodes.forEach(node => {
        const x = node.x * width;
        const y = node.y * height;
        
        // Node glow and color based on status
        let glowColor, nodeColor;
        
        switch(node.status) {
            case 'compromised':
                glowColor = 'rgba(255, 68, 68, 0.5)';
                nodeColor = '#ff4444';
                break;
            case 'at-risk':
                glowColor = 'rgba(255, 165, 0, 0.5)';
                nodeColor = '#ffa500';
                break;
            case 'predicted':
                glowColor = 'rgba(57, 255, 20, 0.5)';
                nodeColor = '#39ff14';
                break;
            case 'isolated':
                glowColor = 'rgba(0, 191, 255, 0.6)';
                nodeColor = '#00bfff';
                break;
            case 'neutralized':
                glowColor = 'rgba(0, 255, 136, 0.6)';
                nodeColor = '#00ff88';
                break;
            default:
                glowColor = 'rgba(57, 255, 20, 0.3)';
                nodeColor = '#39ff14';
        }
        
        // Outer glow
        networkCtx.beginPath();
        networkCtx.arc(x, y, 25, 0, Math.PI * 2);
        networkCtx.fillStyle = glowColor;
        networkCtx.fill();
        
        // Inner circle
        networkCtx.beginPath();
        networkCtx.arc(x, y, 15, 0, Math.PI * 2);
        networkCtx.fillStyle = nodeColor;
        networkCtx.fill();
        
        // Draw solution indicators
        if (demoState.showSolutions && node.status === 'isolated') {
            // Shield icon for isolated nodes
            networkCtx.beginPath();
            networkCtx.arc(x, y, 20, 0, Math.PI * 2);
            networkCtx.strokeStyle = '#00bfff';
            networkCtx.lineWidth = 3;
            networkCtx.stroke();
            networkCtx.lineWidth = 2;
        }
        
        if (demoState.showSolutions && node.status === 'neutralized') {
            // Green pulsing ring for neutralized threats
            networkCtx.beginPath();
            networkCtx.arc(x, y, 28, 0, Math.PI * 2);
            networkCtx.strokeStyle = '#00ff88';
            networkCtx.lineWidth = 3;
            networkCtx.stroke();
            networkCtx.lineWidth = 2;
        }
        
        // Draw solution type icon
        if (demoState.showSolutions && node.solutionType && (node.status === 'isolated' || node.status === 'neutralized')) {
            networkCtx.fillStyle = '#ffffff';
            networkCtx.font = 'bold 14px Arial';
            networkCtx.textAlign = 'center';
            networkCtx.textBaseline = 'middle';
            
            let icon = '';
            switch(node.solutionType) {
                case 'quarantine':
                    icon = '🔒';
                    break;
                case 'segmentation':
                    icon = '🚧';
                    break;
                case 'privileged_revoked':
                    icon = '🔐';
                    break;
                case 'exfiltration_blocked':
                    icon = '🔥';
                    break;
            }
            
            if (icon) {
                networkCtx.fillText(icon, x + 25, y - 25);
            }
        }
        
        // Node label
        networkCtx.fillStyle = '#c9d1d9';
        networkCtx.font = '12px Arial';
        networkCtx.textAlign = 'center';
        networkCtx.textBaseline = 'alphabetic';
        networkCtx.fillText(node.name, x, y + 40);
    });
}

function updateNetwork(currentTime) {
    networkNodes.forEach(node => {
        // Check if solution has been applied
        if (node.solutionTime >= 0 && currentTime >= node.solutionTime + 10) {
            node.status = 'neutralized';
        } else if (node.solutionTime >= 0 && currentTime >= node.solutionTime) {
            node.status = 'isolated';
        } else if (node.compromiseTime >= 0 && currentTime >= node.compromiseTime) {
            if (currentTime < node.compromiseTime + 15) {
                node.status = 'at-risk';
            } else {
                node.status = 'compromised';
            }
        } else if (node.compromiseTime >= 0 && currentTime >= node.compromiseTime - 15 && currentTime < node.compromiseTime) {
            node.status = 'predicted';
        } else {
            node.status = 'safe';
        }
    });
    
    drawNetwork();
}

function addEventToFeed(event) {
    const eventsFeed = document.getElementById('eventsFeed');
    if (!eventsFeed) return;
    
    const eventItem = document.createElement('div');
    eventItem.className = `event-item ${event.type}`;
    
    const confidenceHtml = event.confidence ? `<div class="event-confidence">Confidence: ${event.confidence}%</div>` : '';
    
    // Add solution information if available and solution view is enabled
    const solutionHtml = (event.solution && demoState.showSolutions) 
        ? `<div class="event-solution"><span class="solution-icon">${event.icon || '✓'}</span> SOLUTION: ${event.solution}</div>` 
        : '';
    
    eventItem.innerHTML = `
        <div class="event-header">
            <div class="event-type">${event.event}</div>
            <div class="event-severity ${event.severity.toLowerCase()}">${event.severity}</div>
        </div>
        <div class="event-description">${event.description}</div>
        <div class="event-action">→ ${event.action}</div>
        ${confidenceHtml}
        ${solutionHtml}
    `;
    
    eventsFeed.insertBefore(eventItem, eventsFeed.firstChild);
    
    // Keep only last 8 events
    while (eventsFeed.children.length > 8) {
        eventsFeed.removeChild(eventsFeed.lastChild);
    }
}

function updatePredictions(currentTime) {
    const predictionsList = document.getElementById('predictionsList');
    if (!predictionsList) return;
    
    predictionsList.innerHTML = '';
    
    predictions.forEach(pred => {
        if (currentTime >= pred.showTime) {
            const predItem = document.createElement('div');
            predItem.className = 'prediction-item';
            predItem.innerHTML = `
                <div class="prediction-phase">${pred.phase}</div>
                <div class="prediction-target">Target: ${pred.target}</div>
                <div class="prediction-confidence">Confidence: ${pred.confidence}%</div>
            `;
            predictionsList.appendChild(predItem);
        }
    });
}

function updateEixScore(currentTime) {
    const gaugeFill = document.getElementById('demoGaugeFill');
    const gaugeText = document.getElementById('demoGaugeText');
    if (!gaugeFill || !gaugeText) return;
    
    let score = 45;
    
    if (currentTime >= 120) {
        score = 87;
    } else if (currentTime >= 60) {
        score = 45 + (currentTime - 60) * (87 - 45) / 60;
    }
    
    score = Math.round(score);
    
    const maxDashArray = 251.2;
    const offset = maxDashArray * (1 - score / 100);
    gaugeFill.style.strokeDashoffset = offset;
    gaugeText.textContent = score;
}

function updateTimeDisplay() {
    const currentTimeEl = document.getElementById('currentTime');
    if (!currentTimeEl) return;
    
    const minutes = Math.floor(demoState.currentTime / 60);
    const seconds = Math.floor(demoState.currentTime % 60);
    currentTimeEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function processDemoTimeline(currentTime) {
    demoTimeline.forEach(event => {
        if (event.timestamp <= currentTime && !demoState.events.includes(event.timestamp)) {
            demoState.events.push(event.timestamp);
            addEventToFeed(event);
        }
    });
}

function animateDemo(timestamp) {
    if (!demoState.isPlaying) return;
    
    if (!demoState.lastTimestamp) demoState.lastTimestamp = timestamp;
    const deltaTime = (timestamp - demoState.lastTimestamp) / 1000;
    demoState.lastTimestamp = timestamp;
    
    demoState.currentTime += deltaTime * demoState.speed;
    
    if (demoState.currentTime >= demoState.totalDuration) {
        demoState.currentTime = demoState.totalDuration;
        pauseDemo();
    }
    
    processDemoTimeline(demoState.currentTime);
    updateNetwork(demoState.currentTime);
    updatePredictions(demoState.currentTime);
    updateEixScore(demoState.currentTime);
    updateTimeDisplay();
    
    if (demoState.isPlaying) {
        demoState.animationFrame = requestAnimationFrame(animateDemo);
    }
}

function playDemo() {
    demoState.isPlaying = true;
    demoState.lastTimestamp = 0;
    const icon = document.getElementById('playPauseIcon');
    if (icon) icon.textContent = '⏸';
    demoState.animationFrame = requestAnimationFrame(animateDemo);
}

function pauseDemo() {
    demoState.isPlaying = false;
    const icon = document.getElementById('playPauseIcon');
    if (icon) icon.textContent = '▶';
    if (demoState.animationFrame) {
        cancelAnimationFrame(demoState.animationFrame);
    }
}

function resetDemo() {
    pauseDemo();
    demoState.currentTime = 0;
    demoState.events = [];
    demoState.lastTimestamp = 0;
    demoState.showSolutions = document.getElementById('toggleSolutions')?.checked ?? true;
    
    // Reset network nodes
    networkNodes.forEach(node => {
        node.status = 'safe';
    });
    
    // Clear events feed
    const eventsFeed = document.getElementById('eventsFeed');
    if (eventsFeed) eventsFeed.innerHTML = '';
    
    // Clear predictions
    const predictionsList = document.getElementById('predictionsList');
    if (predictionsList) predictionsList.innerHTML = '';
    
    // Reset EiX score
    updateEixScore(0);
    updateTimeDisplay();
    drawNetwork();
}

function openDemoModal() {
    if (demoModal) {
        demoModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        initNetworkCanvas();
        drawNetwork();
        resetDemo();
        setTimeout(() => playDemo(), 500);
    }
}

function closeDemoModal() {
    if (demoModal) {
        demoModal.classList.remove('active');
        document.body.style.overflow = '';
        resetDemo();
    }
}

// Event Listeners
if (requestDemoBtn) {
    requestDemoBtn.addEventListener('click', openDemoModal);
}

if (contactDemoBtn) {
    contactDemoBtn.addEventListener('click', openDemoModal);
}

if (closeDemoBtn) {
    closeDemoBtn.addEventListener('click', closeDemoModal);
}

if (returnToSiteBtn) {
    returnToSiteBtn.addEventListener('click', closeDemoModal);
}

if (playPauseBtn) {
    playPauseBtn.addEventListener('click', () => {
        if (demoState.isPlaying) {
            pauseDemo();
        } else {
            playDemo();
        }
    });
}

if (resetBtn) {
    resetBtn.addEventListener('click', resetDemo);
}

if (speedSlider) {
    speedSlider.addEventListener('input', (e) => {
        demoState.speed = parseFloat(e.target.value);
        if (speedValue) {
            speedValue.textContent = demoState.speed + 'x';
        }
    });
}

// Layer toggles
const toggleAlerts = document.getElementById('toggleAlerts');
const togglePredictions = document.getElementById('togglePredictions');
const togglePaths = document.getElementById('togglePaths');

if (toggleAlerts) {
    toggleAlerts.addEventListener('change', (e) => {
        const eventsFeed = document.getElementById('eventsFeed');
        if (eventsFeed) {
            eventsFeed.style.display = e.target.checked ? 'flex' : 'none';
        }
    });
}

if (togglePredictions) {
    togglePredictions.addEventListener('change', (e) => {
        const predictionsList = document.getElementById('predictionsList');
        if (predictionsList) {
            predictionsList.style.display = e.target.checked ? 'flex' : 'none';
        }
    });
}

if (togglePaths) {
    togglePaths.addEventListener('change', (e) => {
        if (networkCanvas) {
            networkCanvas.style.opacity = e.target.checked ? '1' : '0.3';
        }
    });
}

// Solution View Toggle
const toggleSolutions = document.getElementById('toggleSolutions');
if (toggleSolutions) {
    toggleSolutions.addEventListener('change', (e) => {
        demoState.showSolutions = e.target.checked;
        
        // Redraw network to show/hide solution indicators
        drawNetwork();
        
        // Update event feed to show/hide solutions
        const eventsFeed = document.getElementById('eventsFeed');
        if (eventsFeed && !e.target.checked) {
            // Hide solution divs
            const solutionDivs = eventsFeed.querySelectorAll('.event-solution');
            solutionDivs.forEach(div => div.style.display = 'none');
        } else if (eventsFeed && e.target.checked) {
            // Show solution divs
            const solutionDivs = eventsFeed.querySelectorAll('.event-solution');
            solutionDivs.forEach(div => div.style.display = 'flex');
        }
    });
}

// Close modal on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && demoModal && demoModal.classList.contains('active')) {
        closeDemoModal();
    }
});

// Resize network canvas on window resize
window.addEventListener('resize', () => {
    if (demoModal && demoModal.classList.contains('active')) {
        initNetworkCanvas();
        drawNetwork();
    }
});

// Animated Counters for Metrics (Preserved from original)
function animateCounter(element, target, duration = 2000, suffix = '%') {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        if (suffix === 's') {
            element.textContent = current.toFixed(1) + suffix;
        } else if (suffix === '%') {
            element.textContent = Math.floor(current) + suffix;
        } else {
            element.textContent = Math.floor(current) + suffix;
        }
    }, 16);
}

// Intersection Observer for Animations
const observerOptions = {
    threshold: 0.3,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            // Animate metric counters
            const metricValue = entry.target.querySelector('.metric-value[data-value]');
            if (metricValue && !metricValue.classList.contains('animated')) {
                metricValue.classList.add('animated');
                const targetValue = parseFloat(metricValue.getAttribute('data-value'));
                
                if (metricValue.textContent.includes('s')) {
                    animateCounter(metricValue, targetValue, 2000, 's');
                } else {
                    animateCounter(metricValue, targetValue, 2000, '%');
                }
            }
            
            // Animate KPI values
            const kpiValue = entry.target.querySelector('.kpi-value[data-kpi]');
            if (kpiValue && !kpiValue.classList.contains('animated')) {
                kpiValue.classList.add('animated');
                const targetValue = parseFloat(kpiValue.getAttribute('data-kpi'));
                
                if (kpiValue.textContent.includes('s')) {
                    animateCounter(kpiValue, targetValue, 2000, 's');
                } else if (kpiValue.textContent.includes('%')) {
                    animateCounter(kpiValue, targetValue, 2000, '%');
                } else {
                    animateCounter(kpiValue, targetValue, 2000, '');
                }
            }
            
            // Animate progress bars
            const progressBar = entry.target.querySelector('.progress-bar[data-progress]');
            if (progressBar && !progressBar.classList.contains('animated')) {
                progressBar.classList.add('animated');
                const targetProgress = parseFloat(progressBar.getAttribute('data-progress'));
                progressBar.style.width = targetProgress + '%';
            }
            
            // Animate EiX gauges
            const gaugeFill = entry.target.querySelector('.gauge-fill[data-score]');
            if (gaugeFill && !gaugeFill.classList.contains('animated')) {
                gaugeFill.classList.add('animated');
                const score = parseFloat(gaugeFill.getAttribute('data-score'));
                const maxDashArray = 251.2;
                const offset = maxDashArray * (1 - score / 100);
                gaugeFill.style.strokeDashoffset = offset;
            }
        }
    });
}, observerOptions);

// Observe all metric cards
const metricCards = document.querySelectorAll('.metric-card');
metricCards.forEach(card => observer.observe(card));

// Observe all KPI items
const kpiItems = document.querySelectorAll('.kpi-item');
kpiItems.forEach(item => observer.observe(item));

// Observe all simulation items with progress bars
const simulationItems = document.querySelectorAll('.simulation-item');
simulationItems.forEach(item => observer.observe(item));

// Observe EiX cards
const eixCards = document.querySelectorAll('.eix-card');
eixCards.forEach(card => observer.observe(card));

// Feature Card Expansion
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach(card => {
    card.addEventListener('click', () => {
        const expanded = card.querySelector('.feature-expanded');
        const isExpanded = expanded.style.maxHeight && expanded.style.maxHeight !== '0px';
        
        // Close all other expanded cards
        featureCards.forEach(otherCard => {
            if (otherCard !== card) {
                const otherExpanded = otherCard.querySelector('.feature-expanded');
                otherExpanded.style.maxHeight = '0';
            }
        });
        
        // Toggle current card
        if (isExpanded) {
            expanded.style.maxHeight = '0';
        } else {
            expanded.style.maxHeight = expanded.scrollHeight + 'px';
        }
    });
});

// Alert Item Hover Effects
const alertItems = document.querySelectorAll('.alert-item');
alertItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        item.style.transform = 'translateX(10px)';
    });
    
    item.addEventListener('mouseleave', () => {
        item.style.transform = 'translateX(0)';
    });
});

// Dashboard Card Expansion
let expandedCard = null;

const dashboardCards = document.querySelectorAll('.dashboard-card');
dashboardCards.forEach(card => {
    card.addEventListener('click', () => {
        if (expandedCard && expandedCard !== card) {
            expandedCard.style.transform = 'scale(1)';
            expandedCard.style.zIndex = '1';
        }
        
        if (expandedCard === card) {
            card.style.transform = 'scale(1)';
            card.style.zIndex = '1';
            expandedCard = null;
        } else {
            card.style.transform = 'scale(1.02)';
            card.style.zIndex = '10';
            expandedCard = card;
        }
    });
});

// Path Node Animation on Scroll
const pathNodes = document.querySelectorAll('.path-node');
const pathObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'scale(1)';
        }
    });
}, { threshold: 0.5 });

pathNodes.forEach(node => {
    node.style.opacity = '0';
    node.style.transform = 'scale(0.8)';
    node.style.transition = 'all 0.5s ease';
    pathObserver.observe(node);
});

// Simulate Real-Time Data Updates
function simulateRealtimeUpdates() {
    // Update active simulations count with pulse
    const activeSimValue = document.querySelector('.sim-value.pulse');
    if (activeSimValue) {
        setInterval(() => {
            const currentValue = parseInt(activeSimValue.textContent);
            const newValue = currentValue + (Math.random() > 0.5 ? 1 : -1);
            if (newValue >= 5 && newValue <= 10) {
                activeSimValue.textContent = newValue;
            }
        }, 5000);
    }
    
    // Add subtle glow animation to critical alerts
    const criticalAlerts = document.querySelectorAll('.alert-item.priority-critical');
    criticalAlerts.forEach(alert => {
        setInterval(() => {
            alert.style.boxShadow = '0 0 20px rgba(255, 68, 68, 0.3)';
            setTimeout(() => {
                alert.style.boxShadow = 'none';
            }, 1000);
        }, 3000);
    });
}

// Initialize real-time updates
simulaterealtimeUpdates();

// Tooltip functionality for EiX cards
const eixElements = document.querySelectorAll('.eix-card');
eixElements.forEach(card => {
    card.addEventListener('mouseenter', () => {
        const riskBadge = card.querySelector('.risk-badge');
        if (riskBadge) {
            riskBadge.style.transform = 'scale(1.1)';
        }
    });
    
    card.addEventListener('mouseleave', () => {
        const riskBadge = card.querySelector('.risk-badge');
        if (riskBadge) {
            riskBadge.style.transform = 'scale(1)';
        }
    });
});

// Timeline Animation
const timelineItems = document.querySelectorAll('.timeline-item');
const timelineObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translate(-50%, -50%) scale(1)';
            }, index * 200);
        }
    });
}, { threshold: 0.5 });

timelineItems.forEach(item => {
    item.style.opacity = '0';
    item.style.transform = 'translate(-50%, -50%) scale(0.5)';
    item.style.transition = 'all 0.5s ease';
    timelineObserver.observe(item);
});

// Keyboard Navigation Support
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && expandedCard) {
        expandedCard.style.transform = 'scale(1)';
        expandedCard.style.zIndex = '1';
        expandedCard = null;
    }
});

// Initialize on page load
window.addEventListener('load', () => {
    // Add entrance animations
    document.body.style.opacity = '1';
    
    // Trigger initial animations for visible elements
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        heroContent.style.animation = 'fadeInUp 1s ease forwards';
    }
});

// Add CSS animation keyframes dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    body {
        opacity: 0;
        transition: opacity 0.3s ease;
    }
`;
document.head.appendChild(style);

console.log('EIDOLON - AI-Driven Threat Intelligence Platform Initialized');